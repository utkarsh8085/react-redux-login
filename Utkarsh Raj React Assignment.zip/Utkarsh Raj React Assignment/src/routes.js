import React from 'react';
import { Route, IndexRoute } from 'react-router';
import  App from './components/App';
import HomePage from './components/home/HomePage';
import LoginPage from './components/LoginPage';
import AboutUs from './components/AboutUs';
import Profile from './components/Profile';
import Team from './components/Team';
import Contact from './components/Contact';

export default (
  <Route path="/" component={App}>
    <IndexRoute component={HomePage} />
    <Route path="login" component={LoginPage} />
    <Route path="aboutus" component={AboutUs}>
    <Route path="profile" component={Profile} />
    <Route path="team" component={Team} />
    <Route path="contact" component={Contact} />
    </Route>
  </Route>
);


import actionTypes from '../constants/AppConstants';
import auth from '../utility/userAuth';
import { browserHistory } from 'react-router';

const loginCheck = (username, password) => {
    return (dispatch) => {
        dispatch(sendingRequest(true));
        // If no username or password was specified, throw a field-missing error
        if (anyElementsEmpty({ username, password })) {
            dispatch(setErrorMessage("Fields shouldn't be empty"));
            dispatch(sendingRequest(false));
            return;
        }
        const loginData = {
            username: username,
            password: password
        };
        auth.login(loginData, (success, err) => {
            // When the request is finished, hide the loading indicator
            dispatch(sendingRequest(false));
            dispatch(setAuthState(success));
            if (success === true) {
                // If the login worked, forward the user to the dashboard and clear the form
                forwardTo('/aboutus');
                dispatch(changeForm({
                    username: "",
                    password: ""
                }));
            } else {
                dispatch(setErrorMessage(err));
            }
        });
    };
};

const setAuthState = (newState) => {
    return { type: actionTypes.SET_AUTH, newState };
};

const changeForm = (newState) => (
    { type: actionTypes.CHANGE_FORM, newState }
);

const sendingRequest = (sending) => {
    return { type: actionTypes.SENDING_REQUEST, sending };
};


const setErrorMessage = (message) => {
    return (dispatch) => {
        dispatch({ type: actionTypes.SET_ERROR_MESSAGE, message });

        const form = document.querySelector('.form-page__form-wrapper');
        if (form) {
            form.classList.add('js-form__err-animation');
            // Removing the animation class after the animation is finished, so it
            // can play again on the next error
            setTimeout(() => {
                form.classList.remove('js-form__err-animation');
            }, 150);

            // Removing the error message after 3 seconds
            setTimeout(() => {
                dispatch({ type: actionTypes.SET_ERROR_MESSAGE, message: '' });
            }, 3000);
        }
    }
};

function forwardTo(location) {
    browserHistory.push(location);
}

function anyElementsEmpty(elements) {
    for (let element in elements) {
        if (!elements[element]) {
            return true;
        }
    }
    return false;
}

module.exports = {
    loginCheck,
    changeForm,
    setErrorMessage
};

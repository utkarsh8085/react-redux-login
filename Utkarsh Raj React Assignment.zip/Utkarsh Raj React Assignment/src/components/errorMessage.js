
import React, { PropTypes } from 'react';
import { connect } from 'react-redux';

class ErrorMessage extends React.Component {
    render() {
        const { userlogin } = this.props;

        const errorMessage = userlogin.errorMessage;
        return (
            errorMessage ?
                <div className="error-wrapper">
                    <p className="error">{errorMessage}</p>
                </div>
                : <div></div>
        );
    }
}

ErrorMessage.propTypes = {
    userlogin: PropTypes.object
};

const mapStateToProps = (state) => ({
    userlogin: state.userlogin
});
export default connect(mapStateToProps)(ErrorMessage);



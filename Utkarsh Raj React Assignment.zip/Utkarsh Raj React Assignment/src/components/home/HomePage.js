import React from 'react';
import {Link} from 'react-router';

class HomePage extends React.Component {
  render() {
    return (
      <div className="jumbotron">
        <h1>React-Redux Assignment</h1>
        <p>React, Redux and React Router in ES6 for ultra-fast web apps.</p>
        <Link to="login" className="btn btn-primary btn-lg">Click here for a login page</Link>
      </div>
    );
  }
}

export default HomePage;

import React , {PropTypes} from 'react';
import { connect } from 'react-redux';
import Form from './LoginForm';
import loginActions  from '../actions/LoginActions';

 class LoginPage extends React.Component  {
        constructor(props) {
            super(props);
            this.userlogin = this.userlogin.bind(this);
        }

     userlogin(){
         this.props.login;
     }


    render() {
        const {userlogin }  = this.props;
        const data = userlogin.formState;
        const currentlySending = userlogin.currentlySending;
        const changeForm = this.props.changeForm;
        const onSubmit = this.props.login;
        const setErrorMessage = this.props.setErrorMessage;

            return (
                <div className="form-page__wrapper">
                    <div className="form-page__form-wrapper">
                        <div className="form-page__form-header">
                            <h2 className="form-page__form-heading">Enter your login details</h2>
                        </div>
                    <Form data={data}
                        changeForm={changeForm}
                        setErrorMessage={setErrorMessage}
                        onSubmit={onSubmit}
                        btnText={"Login"}
                        currentlySending={currentlySending}/>
                    </div>
                </div>
            );
    }
    }

function mapStateToProps(state, ownProps) {
  return {
    userlogin: state.userlogin
  };
}

function mapDispatchToProps(dispatch) {
  return {
    login: (username, password) => dispatch(loginActions.loginCheck(username, password)),
    changeForm: newState => dispatch(loginActions.changeForm(newState)),
    setErrorMessage: newState => dispatch(loginActions.setErrorMessage(newState))
  };
}

LoginPage.propTypes = {
    userlogin: PropTypes.object.isRequired,
    login : PropTypes.func.isRequired,
    changeForm : PropTypes.func.isRequired,
    setErrorMessage : PropTypes.func.isRequired
};

export default connect(mapStateToProps,mapDispatchToProps)(LoginPage);

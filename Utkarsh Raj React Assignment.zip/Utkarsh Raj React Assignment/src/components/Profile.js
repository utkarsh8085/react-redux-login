import React from 'react';

class Profile extends React.Component {
  render() {
    return (
      <div>
        <h1>Profile</h1>
        <p>React Profile</p>
      </div>
    );
  }
}

export default Profile;

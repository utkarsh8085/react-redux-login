import React from 'react';

class Team extends React.Component {
  render() {
    return (
      <div>
        <h1>Our Team</h1>
        <p>Team details page</p>
      </div>
    );
  }
}

export default Team;

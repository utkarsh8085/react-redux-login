const React = require('react');

class LoadingSection extends React.Component {
    render() {
        return (
            <section className="loading-section">
                <div className="loading-section__spinner">
                    <div className="loading-section__spinner-wrapper">
                        <div className="loading-section__rotator">
                            <div className="loading-section__inner-spin"></div>
                            <div className="loading-section__inner-spin"></div>
                        </div>
                    </div>
                </div>
            </section>
        );
    }
}

module.exports = LoadingSection;

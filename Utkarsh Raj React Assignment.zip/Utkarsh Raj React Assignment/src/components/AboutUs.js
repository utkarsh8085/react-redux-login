import React, {PropTypes} from 'react';
import { Link, IndexLink } from 'react-router';

class AboutUS extends React.Component {
  render() {
    return (
      <div>
    <nav>
      <Link to="/aboutus/profile" replace="true"  activeClassName="active">Profile</Link>
      {" | "}
      <Link to="/aboutus/team" activeClassName="active">Team</Link>
      {" | "}
      <Link to="/aboutus/contact" activeClassName="active">Contact</Link>
      {}
    </nav>
       {this.props.children}
      </div>
    );
  }
}

AboutUS.propTypes = {
children: PropTypes.object.isRequired
};

export default AboutUS;

import React from 'react';
import { PropTypes } from 'react';
import ErrorMessage from './errorMessage';

const assign = Object.assign || require('object.assign');

class LoginForm extends React.Component {
    constructor(props) {
        super(props);
        this.changeEmail = this.changeEmail.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        this.changePassword = this.changePassword.bind(this);
        this.handleOnBlurMail = this.handleOnBlurMail.bind(this);
        this.isValidEmail = this.isValidEmail.bind(this);
    }

    handleOnBlurMail(event){
        const { value } = event.target;
        let isValid = this.isValidEmail(value);
        const emailError = isValid ? '' : "Invalid Email";
        this.props.setErrorMessage(emailError);
    }

    isValidEmail(value) {
        const EMAIL_REGEX = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        const emailIsValid = EMAIL_REGEX.test(value);
        return value ==='' || emailIsValid;
    }

    // Change the email in the app state
    changeEmail(evt) {
        let newState = this.mergeWithCurrentState({
            username: evt.target.value
        });
        this.emitChange(newState);
    }

    // Change the password in the app state
    changePassword(evt) {
        let newState = this.mergeWithCurrentState({
            password: evt.target.value
        });

        this.emitChange(newState);
    }

    // Merges the current state with a change
    mergeWithCurrentState(change) {
        return assign(this.props.data, change);
    }

    // Emits a change of the form state to the application state
    emitChange(newState) {
        this.props.changeForm(newState);
    }

    // onSubmit call the passed onSubmit function
    onSubmit(evt) {
        evt.preventDefault();
        this.props.onSubmit(this.props.data.username, this.props.data.password);
    }

    render() {
        const { data, currentlySending, changeForm, btnText , setErrorMessage} = this.props;
        return (
            <form className="form" onSubmit={this.onSubmit}>
            <ErrorMessage />
                <div className="form__field-wrapper">
                    <input className="form__field-input" onBlur={this.handleOnBlurMail} type="text" id="username" value={this.props.data.username} placeholder="Enter your email" onChange={this.changeEmail} />
                    <label className="form__field-label" htmlFor="username">User Email</label>
                </div>
                <div className="form__field-wrapper">
                    <input className="form__field-input" id="password" type="password" value={this.props.data.password} placeholder="••••••••••" onChange={this.changePassword} />
                    <label className="form__field-label" htmlFor="password">Password</label>
                </div>
                <div className="form__submit-btn-wrapper">
                    <button className="form__submit-btn" type="submit">{btnText}</button>
                </div>
            </form>
        );
    }
}

LoginForm.propTypes = {
    onSubmit: PropTypes.func.isRequired,
    btnText: PropTypes.string.isRequired,
    data: PropTypes.object.isRequired,
    changeForm: PropTypes.func.isRequired,
    currentlySending: PropTypes.bool,
    setErrorMessage: PropTypes.func.isRequired
};

export default LoginForm;

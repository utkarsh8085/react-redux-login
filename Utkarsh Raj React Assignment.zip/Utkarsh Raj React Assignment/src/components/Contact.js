import React from 'react';

class Contact extends React.Component {
  render() {
    return (
      <div>
        <h1>Contact Us</h1>
        <p>Lets get in touch</p>
      </div>
    );
  }
}

export default Contact;

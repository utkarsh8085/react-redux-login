import _ from 'lodash';

const response = {
    "users": [{
            "mailId": "user1@gmail.com",
            "password": "user1"
        },
        {
            "mailId": "user2@gmail.com",
            "password": "user2"
        },
        {
            "mailId": "user3@gmail.com",
            "password": "user3"
        },
        {
            "mailId": "user4@gmail.com",
            "password": "user4"
        },
        {
            "mailId": "user5@gmail.com",
            "password": "user5"
        },
        {
            "mailId": "user6@gmail.com",
            "password": "user6"
        }
    ]
};

const auth = {

    login(loginData, callback) {

        window.console.log("My Response", response);
        const user_loggedIn = _.find(response.users, function (obj) {
            return obj.mailId === loginData.username;
        }) || false;
        if (user_loggedIn) {
            const password_entered = user_loggedIn.password;
            if (password_entered === loginData.password) {
                callback(true);
            }
            else {
            const error = "Invalid login Details";
            callback(false, error);
        }
        }
   }
};

module.exports = auth;

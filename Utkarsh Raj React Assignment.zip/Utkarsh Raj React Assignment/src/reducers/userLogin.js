
import actionTypes from '../constants/AppConstants';
// Object.assign is not yet fully supported in all browsers, so we fallback to
// a polyfill
const assign = Object.assign || require('object.assign');

// The initial application state
function setInitialState() {
    return {
        formState: {
            username: '',
            password: ''
        },
        currentlySending: false,
        loggedIn: true,
        errorMessage: ''
    };
}

const initialState = setInitialState();

function userlogin(state = initialState, action) {
    switch (action.type) {
        case 'CHANGE_FORM':
            return assign({}, state, {
                formState: action.newState
            });
        case actionTypes.SET_AUTH:
            return assign({}, state, {
                loggedIn: action.newState
            });
        case actionTypes.SENDING_REQUEST:
            return assign({}, state, {
                currentlySending: action.sending
            });
        case actionTypes.SET_ERROR_MESSAGE:
            return assign({}, state, {
                errorMessage: action.message
            });
        default:
            return state;
    }
}

module.exports = userlogin;

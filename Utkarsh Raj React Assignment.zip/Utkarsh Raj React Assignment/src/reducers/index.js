import {combineReducers} from 'redux';
import  userlogin from './userLogin';

const rootReducer = combineReducers({
userlogin
});

export default rootReducer;
